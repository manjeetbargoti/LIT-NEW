<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SocialInitiativeImages extends Model
{
    //
    protected $fillable = [
        'image_name','image_size','social_initiative_id'
    ];
}
