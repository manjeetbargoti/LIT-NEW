

<?php $__env->startSection('content'); ?>
<header class="head">
    <div class="main-bar">
        <div class="row">
            <div class="col-6">
                <h4 class="m-t-5">
                    <i class="fa fa-home"></i>
                    System Settings
                </h4>
            </div>
        </div>
    </div>
</header>
<div class="outer">
    <div class="container">
        <div class="row">
            <div class="col-xl-12 m-auto">
                <div class="card">
                    <div class="card-header">Add/Edit Custom Code</div>
                    <div class="card-body">

                        <?php if($errors->any()): ?>
                        <ul class="alert alert-danger">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <?php endif; ?>

                        <form method="post" class="form-horizontal login_validator" enctype="multipart/form-data"
                            id="form_inline_validator">
                            <?php echo csrf_field(); ?>
                            <!-- Custom Header Code Input Field -->
                            <div class="form-group row">
                                <div class="col-xl-8 m-auto">
                                    <label>Custom Code: Header</label>
                                    <textarea name="custom_code_header" id="custom_code_header" rows="7"
                                        class="form-control"><?php echo $header; ?></textarea>
                                </div>
                            </div>
                            <!-- /.Custom Header Code Input Field -->

                            <!-- Custom Footer Code Input Field -->
                            <div class="form-group row">
                                <div class="col-xl-8 m-auto">
                                    <label>Custom Code: Footer</label>
                                    <textarea name="custom_code_footer" id="custom_code_footer" rows="7"
                                        class="form-control"><?php echo $footer; ?></textarea>
                                </div>
                            </div>
                            <!-- /.Custom Footer Code Input Field -->

                            <div class="form-actions form-group row">
                                <div class="col-xl-4 m-auto">
                                    <input type="reset" value="Reset" class="btn btn-warning pull-left">
                                    <input type="submit" value="Save File" class="btn btn-primary pull-right">
                                </div>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/feheuuyiwgw9/public_html/lit.einaim.org/resources/views/admin/system/code.blade.php ENDPATH**/ ?>