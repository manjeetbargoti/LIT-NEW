
<?php $__env->startSection('content'); ?>

<header class="head">
    <div class="main-bar">
        <div class="row">
            <div class="col-6">
                <h4 class="m-t-5">
                    <i class="fa fa-home"></i>
                    Settings
                </h4>
            </div>
        </div>
    </div>
</header>
<div class="outer">
    <div class="container">
        <div class="row">
            <div class="col-md-12 m-auto">
                <div class="card">
                    <div class="card-header">Banners</div>
                    <div class="card-body">
                        <a href="<?php echo e(url('admin/banner/add')); ?>" class="btn btn-success btn-sm" title="Add New Page">
                            <i class="fa fa-plus" aria-hidden="true"></i> Add New
                        </a>
                        <br />
                        <br />
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>S.No</th>
                                        <th>Image</th>
                                        <th>Title</th>
                                        <th>Small Test</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><img width="200" src="<?php echo e(url('/images/banners/'.$bn->image)); ?>" alt=""></td>
                                        <td><a href="<?php echo e(url('/images/banners/'.$bn->image)); ?>"><?php echo e($bn->title); ?></a></td>
                                        <td><?php echo e($bn->small_text); ?></td>
                                        <td><?php if($bn->status == 1): ?>
                                            <a href="/admin/banner/<?php echo e($bn->id); ?>/disable" title="Disable"
                                                class="badge badge-success badge-sm">Enable</a>
                                            <?php else: ?>
                                            <a href="/admin/banner/<?php echo e($bn->id); ?>/enable" title="Enable"
                                                class="badge badge-danger badge-sm">Disable</a>
                                            <?php endif; ?></td>
                                        <td><a href="<?php echo e(url('/admin/banner/'.$bn->id.'/edit')); ?>" title="Edit"
                                                class="badge badge-warning badge-sm"><i class="fa fa-edit"></i></a>
                                        <a href="<?php echo e(url('/admin/banner/'.$bn->id.'/delete')); ?>" title="Delete"
                                                class="badge badge-danger badge-sm"><i class="fa fa-trash"></i></a></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/feheuuyiwgw9/public_html/lit.einaim.org/resources/views/admin/settings/banners/banners.blade.php ENDPATH**/ ?>