
<?php $__env->startSection('title', 'Single Title'); ?>
<?php $__env->startSection('content'); ?>

<!-- slider start -->
<div id="litsliderabt" class="carousel slide" data-ride="carousel">
    <div class="carousel-inner">
        <div class="carousel-item active">
            <img class="d-block w-100" src="<?php echo e(asset('front/dist/img/about/banner.jpg')); ?>" alt="First slide">
            <h3> <?php if(!empty($data->initiative_name)): ?> <?php echo e($data->initiative_name); ?> <?php elseif(!empty($data->service_name)): ?>
                <?php echo e($data->service_name); ?> <?php endif; ?> </h3>
        </div>
    </div>
</div>


<!-- Project Details Box -->
<section id="projectdetl">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-lg-6 float-left px-0 m-auto">
                <img class="d-block img-responsive m-auto" width="300"
                    src="<?php echo e(asset('images/initiative/large/'.$siImage->image_name)); ?>" alt="Second slide">
            </div>
            <div class="col-md-12 col-lg-6 pl-4">
                <img src="<?php echo e(asset('front/dist/img/home/heading-icon.png')); ?>" class="mb-2 mx-auto" alt="">
                <h2 class="mb-2">
                    <?php if(!empty($data->initiative_name)): ?><?php echo e($data->initiative_name); ?><?php elseif(!empty($data->service_name)): ?><?php echo e($data->service_name); ?><?php endif; ?>
                </h2>
                <span class="col-12 col-lg-3">
                    <select name="budget" id="budgetList" class="form-control col-sm-3">
                        <?php if(empty($data->budget)): ?>
                        <?php $__currentLoopData = $data2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($d2->id); ?>">USD <?php echo e($d2->budget); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <option>USD <?php echo e($data->budget); ?></option>
                        <?php endif; ?>
                    </select>
                </span>
                <span class="pt-2">
                    <li> <b>Location</b>: <?php echo e($data->city); ?>, <?php echo e($data->state); ?>, <?php echo e($data->country); ?></li>
                </span>
                <ul class="p-0">
                    <li> <b>Title</b>:
                        <?php if(!empty($data->initiative_name)): ?><?php echo e($data->initiative_name); ?><?php elseif(!empty($data->service_name)): ?><?php echo e($data->service_name); ?><?php endif; ?>
                    </li>
                    <li><b>Program Stage</b>: <?php echo e($data->program_stage); ?></li>
                    <?php if($data->video_link): ?>
                    <li><b>Video Link</b>: <a target="_blank" href="<?php echo e($data->video_link); ?>"><?php echo e($data->video_link); ?></a>
                    </li>
                    <?php endif; ?>
                    <li class="d-none"> <b>Budget ID</b>: <span id="budg_id"><?php echo e($data->budget_id); ?></span> </li>
                </ul>
                <div class="btnbx mt-2">
                    <?php if(!empty($data->initiative_name)): ?>
                    <a href="<?php echo e(url('/social-initiative/add-to-cart/'.$data->id)); ?>"
                        class="btn btn-primary text-uppercase"> Add to Impact Box</a>
                    <?php elseif(!empty($data->service_name)): ?>
                    <a href="<?php echo e(url('/digital-service/add-to-cart/'.$data->id)); ?>"
                        class="btn btn-primary text-uppercase"> Add to Impact Box</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-12 mt-4">
                <table class="table table-bordered table-striped">
                    <tr>
                        <th>Beneficiaries</th>
                        <td id="budg_ben"><?php echo e($data->beneficiaries); ?></td>
                    </tr>
                    <tr>
                        <th>SDG</th>
                        <td><?php echo e($data->area_impact_sdg); ?></td>
                    </tr>
                    <tr>
                        <th>Initiative Duration</th>
                        <td><span id="budg_dur"><?php echo e($data->duration); ?></span> <span
                                id="budg_tp"><?php echo e($data->time_period); ?></span></td>
                    </tr>
                    <tr>
                        <th>Out-Reach</th>
                        <td><span id="budg_outreach"><?php echo e($data->outreach); ?></span></td>
                    </tr>
                    <tr>
                        <th>Initiative Description</th>
                        <td><?php echo $data->initiative_description; ?></td>
                    </tr>
                    <tr>
                        <th>Scalability of this project</th>
                        <td><?php echo $data->project_scalability; ?></td>
                    </tr>
                    <tr>
                        <th>Project's relevance to the SDG's</th>
                        <td><?php echo $data->sdg_relevance; ?></td>
                    </tr>
                    <tr>
                        <th>Project's relevance to National Agenda</th>
                        <td><?php echo $data->relevance_national_agenda; ?></td>
                    </tr>
                    <tr>
                        <th>How innovative is the project? </th>
                        <td><?php echo $data->project_innovation; ?></td>
                    </tr>
                    <tr>
                        <th>List of benefits of the program * </th>
                        <td><?php echo $data->program_benefits; ?></td>
                    </tr>
                    <tr>
                        <th>Program Stage</th>
                        <td><?php echo $data->program_stage; ?></td>
                    </tr>
                    <tr>
                        <th>Location</th>
                        <td><?php echo e($data->street); ?>, <?php echo e($data->region); ?>,<?php echo e($data->city); ?>, <?php echo e($data->state); ?>,
                            <?php echo e($data->country); ?></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/feheuuyiwgw9/public_html/lit.einaim.org/resources/views/front/social_initiatives/detail_page.blade.php ENDPATH**/ ?>